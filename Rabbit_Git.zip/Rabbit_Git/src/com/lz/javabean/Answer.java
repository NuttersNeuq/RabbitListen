package com.lz.javabean;

public class Answer {
	private String nickname;
	private String portrait;
	private String zcount;
	private String to;
	private String ansid;
	private String content;
	private long time;
	private boolean ifz;
	public String getNickname() {
		return nickname;
	}
	public void setNickname(String nickname) {
		this.nickname = nickname;
	}
	public String getPortrait() {
		return portrait;
	}
	public void setPortrait(String portrait) {
		this.portrait = portrait;
	}
	public String getZcount() {
		return zcount;
	}
	public void setZcount(String zcount) {
		this.zcount = zcount;
	}
	public String getTo() {
		return to;
	}
	public void setTo(String to) {
		this.to = to;
	}
	public String getAnsid() {
		return ansid;
	}
	public void setAnsid(String ansid) {
		this.ansid = ansid;
	}
	public String getContent() {
		return content;
	}
	public void setContent(String content) {
		this.content = content;
	}
	public long getTime() {
		return time;
	}
	public void setTime(long time) {
		this.time = time;
	}
	public boolean isIfz() {
		return ifz;
	}
	public void setIfz(boolean ifz) {
		this.ifz = ifz;
	}
}
