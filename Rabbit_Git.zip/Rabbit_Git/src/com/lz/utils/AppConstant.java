package com.lz.utils;


public class AppConstant
{
		public static final String HOST= "121.40.185.131";
		public static final String HOST_TWO="http://121.40.185.131";
		public static final String PORTRAIT_URL="http://ncc.neuq.edu.cn/box/user/portrait/";
		public static final String LOGIN_URL="http://121.40.185.131/android/login.php";
		public static final String LOGIN_USER_INFO_URL="http://121.40.185.131/android/userinfo.php";
		public static final String QUESTION_LIST_URL ="http://121.40.185.131/android/listenquestion.php";
		public static final String NOTE_FOLLOW_URL="http://121.40.185.131/android/note.php";
		public static final String NOTE_ZAN_URL="http://121.40.185.131/android/note.php";
		public static final String NOTE_DELETE_URL="http://121.40.185.131/android/note.php";
		public static final String NOTE_NEW_URL="http://121.40.185.131/android/note.php";
		public static final String NOTE_UPDATE_URL = "http://121.40.185.131/android/note.php";
		public static final String TREE_QUESTION_LIST_URL="http://121.40.185.131/android/treequestion.php";
		public static final String TREE_NOTE_LIST_URL="http://121.40.185.131/android/treenote.php";
		public static final String TREE_BLOG_LIST_URL="http://121.40.185.131/android/b.php";
		public static final String QUESTION_ANSWER_URL = "http://121.40.185.131/android/showquestion.php";
		public static final String QUESTION_ANSWER_ZAN_URL="http://121.40.185.131/android/qansifz.php";
		public static final String QUESTION_FOLLOW_URL = "http://121.40.185.131/android/fquestion.php";
		public static final String QUESTION_NEW_URL ="http://121.40.185.131/android/addquestion.php";
		public static final String BLOG_ANSWER_URL="http://121.40.185.131/android/b.php";
		public static final String BLOG_ANSWER_ZAN_URL = "http://121.40.185.131/android/b.php";
		public static final String BLOG_ZAN_URL = "http://121.40.185.131/android/b.php";
		public static final String BLOG_NEW_URL="http://121.40.185.131/android/b.php";
		
		public static final String QUESTION_REPLY_QUESTION_URL = "http://121.40.185.131/android/answerquestion.php";
		public static final String QUESTION_REPLY_ANSWER_URL ="http://121.40.185.131/android/answeranswer.php";
		public static final String BLOG_REPLY_ANSWER_URL = "http://121.40.185.131/android/b.php";
		public static final String BLOG_REPLY_BLOG_URL = "http://121.40.185.131/android/b.php";
		
		public static final String FANED_LIST_URL ="http://121.40.185.131/android/fanedlist.php";
		public static final String FAN_LIST_URL ="http://121.40.185.131/android/fanlist.php";
		public static final String PERSONALINFO_URL="http://121.40.185.131/android/userweb.php";
		public static final String PERSONAL_INFO_NOTE_LIST_URL = "http://121.40.185.131/android/note.php";
		public static final String PERSONAL_INFO_COLLECT_NOTE_LIST_URL ="http://121.40.185.131/android/note.php";
		public static final String PERSONAL_INFO_COLLECT_QUESTION_LIST_URL = "http://121.40.185.131/android/question.php";
		public static final String PERSONAL_INFO_QUESTION_LIST_URL = "http://121.40.185.131/android/question.php";
		public static final String PERSONAL_INFO_QUESTION_REPLY_NOTE_LIST_URL ="http://121.40.185.131/android/question.php";
		public static final String PERSONAL_INFO_BLOG_REPLY_LIST_URL = "http://121.40.185.131/android/b.php";
		public static final String PERSONAL_INFO_BLOG_LIST_URL = "http://121.40.185.131/android/b.php";
		public static final String PERSONAL_INFO_EDIT_MOTTO = "http://121.40.185.131/android/mottoset.php";
		public static final String PERSONAL_INFO_FOLLOW="http://121.40.185.131/android/userf.php";
		
		public static final String REGISTER_URL="http://121.40.185.131/android/reg.php";
		
		public static final String SHARE_NOTE_LIST_URL ="http://121.40.185.131/android/note.php";
		public static final String SHARE_COMMENT_URL = "http://121.40.185.131/android/comment.php";
		public static final String GUIDE_THREE_POST_LABEL_URL = "http://121.40.185.131/android/savelabel.php";
		public static final String FEED_BACK_URL = "http://121.40.185.131/android/feedback.php";
		public static final String PERSONAL_INFO_LABEL_URL = "http://121.40.185.131/android/label.php";
		
		public static final String NOTIFY_TOGGLE_URL ="http://121.40.185.131/android/notigytoggle.php";
		public static final String STUDY_NOTIFY_URL = "http://121.40.185.131/android/studyremind.php";
		public static final String NOTIFICATION_URL = "http://121.40.185.131/android/notification.php";
		public static final String LOGOUT_URL ="http://121.40.185.131/android/exit.php";
		
}
