package com.lz.utils;

import android.graphics.Bitmap;

public class StaticInfos {
	public static boolean isLogin=false;
	public static String phpsessid="default";
	public static String nickname="default";
	public static String portrait="default";
	public static String uid="default";
	public static String sqlhost="default";
	public static String mp3host="default";
	public static String mp3url="default";
	public static String lrcurl="default";
	public static String portraiturl="default";
	public static String motto="请编辑你的格言";
	public static String notifyToggle="false";
	public static Bitmap portraitBm;
}
